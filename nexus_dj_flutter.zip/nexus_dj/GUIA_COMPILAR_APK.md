# 🎧 NEXUS DJ — Guía para compilar el APK

## ¿Qué necesitas instalar?

### Paso 1: Instalar Flutter SDK
1. Ve a: https://docs.flutter.dev/get-started/install/windows/mobile
2. Descarga Flutter SDK (botón azul "Download Flutter SDK")
3. Extrae la carpeta en `C:\flutter`
4. Agrega `C:\flutter\bin` a las variables de entorno PATH:
   - Busca "Variables de entorno" en Windows
   - En "Variables del sistema" → PATH → Editar → Nuevo → escribe `C:\flutter\bin`

### Paso 2: Instalar Android Studio
1. Ve a: https://developer.android.com/studio
2. Descarga e instala Android Studio
3. Al abrirlo, sigue el asistente de configuración inicial
4. Instala el Android SDK (lo pide automáticamente)

### Paso 3: Aceptar licencias de Android
Abre una terminal (cmd) y ejecuta:
```
flutter doctor --android-licenses
```
Acepta todo con `y` + Enter

### Paso 4: Verificar instalación
```
flutter doctor
```
Debes ver marcas ✓ en Flutter y Android toolchain.

---

## Compilar el APK

### Paso 5: Coloca la carpeta del proyecto
Copia la carpeta `nexus_dj` en tu escritorio o en `C:\proyectos\nexus_dj`

### Paso 6: Abre terminal en la carpeta del proyecto
```
cd C:\proyectos\nexus_dj
```

### Paso 7: Descarga dependencias
```
flutter pub get
```

### Paso 8: Compila el APK
```
flutter build apk --release
```

Esto tarda 3-5 minutos la primera vez.

### Paso 9: Encuentra tu APK
El archivo estará en:
```
nexus_dj\build\app\outputs\flutter-apk\app-release.apk
```

---

## Instalar en Android

### Opción A — Cable USB:
1. En tu teléfono: Ajustes → Acerca del teléfono → toca "Número de compilación" 7 veces
2. Vuelve → Opciones de desarrollador → activa "Depuración USB"
3. Conecta el cable y ejecuta:
```
flutter install
```

### Opción B — Transferir el APK:
1. Copia `app-release.apk` al teléfono (por WhatsApp, cable, Google Drive, etc.)
2. En el teléfono: Ajustes → Seguridad → activa "Fuentes desconocidas"
3. Abre el archivo APK y toca "Instalar"

---

## ¿Problemas?
- Si `flutter doctor` muestra errores, copia el error y búscalo en Google
- El error más común es la ruta del SDK: asegúrate que `local.properties` apunte a tu SDK
- Para soporte: https://flutter.dev/community

---

## Funciones de NEXUS DJ incluidas:
- ✅ 2 Decks con reproducción real de audio
- ✅ Detección automática de BPM
- ✅ Crossfader con curva de igual potencia
- ✅ EQ 3 bandas por canal
- ✅ Pitch/tempo ±10%
- ✅ SYNC automático de BPM
- ✅ 4 Hot Cues por deck (mantén presionado para borrar)
- ✅ Loops de ½, 1, 2, 4, 8 barras
- ✅ 8 efectos FX con parámetros ajustables
- ✅ Visualizador de espectro animado
- ✅ Vinilo giratorio con scratch táctil
- ✅ Waveform interactiva (toca para hacer scrub)
- ✅ VU Meter animado
