import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import '../theme.dart';
import '../widgets/deck_widget.dart';
import '../widgets/crossfader_widget.dart';
import '../widgets/mixer_widget.dart';
import '../widgets/fx_widget.dart';
import '../widgets/spectrum_widget.dart';

class DJScreen extends StatefulWidget {
  const DJScreen({super.key});
  @override
  State<DJScreen> createState() => _DJScreenState();
}

class _DJScreenState extends State<DJScreen> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final state = context.watch<DJAppState>();
    return Scaffold(
      backgroundColor: kBg,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(state),
            const SpectrumWidget(),
            Expanded(
              child: _tab == 0
                  ? _buildMainView(state)
                  : _tab == 1
                      ? const FxWidget()
                      : _buildInfoView(),
            ),
            _buildBottomNav(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(DJAppState state) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: kBg2,
        border: Border(bottom: BorderSide(color: kBorder)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          ShaderMask(
            shaderCallback: (bounds) => const LinearGradient(
              colors: [kAccentA, kAccentC, kAccentB],
            ).createShader(bounds),
            child: const Text(
              'NEXUS DJ',
              style: TextStyle(
                fontFamily: 'Orbitron',
                fontSize: 20,
                fontWeight: FontWeight.w900,
                letterSpacing: 6,
                color: Colors.white,
              ),
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                state.masterBpm.toStringAsFixed(1),
                style: const TextStyle(
                  fontFamily: 'Orbitron',
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: kAccentG,
                ),
              ),
              const Text(
                'MASTER BPM',
                style: TextStyle(fontSize: 8, color: kTextDim, letterSpacing: 3),
              ),
            ],
          ),
          Row(
            children: [
              _headerBtn('A', kAccentA),
              const SizedBox(width: 6),
              _headerBtn('B', kAccentB),
            ],
          ),
        ],
      ),
    );
  }

  Widget _headerBtn(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        border: Border.all(color: color),
        borderRadius: BorderRadius.circular(4),
        boxShadow: [BoxShadow(color: color.withOpacity(0.3), blurRadius: 6)],
      ),
      child: Text(
        'DECK $label',
        style: TextStyle(
          fontFamily: 'Orbitron',
          fontSize: 9,
          fontWeight: FontWeight.bold,
          color: color,
          letterSpacing: 1,
        ),
      ),
    );
  }

  Widget _buildMainView(DJAppState state) {
    return SingleChildScrollView(
      child: Column(
        children: [
          IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(child: DeckWidget(deckId: 'A')),
                Container(width: 1, color: kBorder),
                Expanded(child: DeckWidget(deckId: 'B')),
              ],
            ),
          ),
          CrossfaderWidget(),
          MixerWidget(),
        ],
      ),
    );
  }

  Widget _buildInfoView() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.music_note, color: kAccentC, size: 48),
            const SizedBox(height: 16),
            const Text(
              'NEXUS DJ v1.0',
              style: TextStyle(
                fontFamily: 'Orbitron',
                fontSize: 20,
                color: kAccentC,
                letterSpacing: 4,
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              '• 2 Decks con BPM automático\n'
              '• Crossfader de precisión\n'
              '• EQ 3 bandas por canal\n'
              '• Sync automático de BPM\n'
              '• 4 Hot Cues por deck\n'
              '• Loops ½ - 8 barras\n'
              '• 8 Efectos FX\n'
              '• Scratch táctil en vinilo\n'
              '• Visualizador de espectro',
              style: TextStyle(color: kText, fontSize: 13, height: 1.8),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomNav() {
    return Container(
      decoration: BoxDecoration(
        color: kBg2,
        border: Border(top: BorderSide(color: kBorder)),
      ),
      child: Row(
        children: [
          _navBtn(0, Icons.tune, 'DECKS'),
          _navBtn(1, Icons.speaker, 'FX'),
          _navBtn(2, Icons.info_outline, 'INFO'),
        ],
      ),
    );
  }

  Widget _navBtn(int index, IconData icon, String label) {
    final active = _tab == index;
    return Expanded(
      child: InkWell(
        onTap: () => setState(() => _tab = index),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: active ? kAccentC : kTextDim, size: 20),
              const SizedBox(height: 3),
              Text(
                label,
                style: TextStyle(
                  fontFamily: 'Orbitron',
                  fontSize: 8,
                  color: active ? kAccentC : kTextDim,
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
