import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import '../theme.dart';

class SpectrumWidget extends StatefulWidget {
  const SpectrumWidget({super.key});
  @override
  State<SpectrumWidget> createState() => _SpectrumWidgetState();
}

class _SpectrumWidgetState extends State<SpectrumWidget> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  final List<double> _bars = List.filled(32, 0);
  final Random _rng = Random();

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 60))
      ..addListener(_updateBars)
      ..repeat();
  }

  void _updateBars() {
    final state = context.read<DJAppState>();
    final active = state.deckA.isPlaying || state.deckB.isPlaying;
    setState(() {
      for (int i = 0; i < _bars.length; i++) {
        if (active) {
          final target = _rng.nextDouble() * (i < 8 ? 0.9 : i < 20 ? 0.6 : 0.3);
          _bars[i] = (_bars[i] * 0.7 + target * 0.3).clamp(0, 1);
        } else {
          _bars[i] = (_bars[i] * 0.85).clamp(0, 1);
        }
      }
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      color: kBg2,
      child: CustomPaint(
        painter: SpectrumPainter(bars: _bars),
        child: const SizedBox.expand(),
      ),
    );
  }
}

class SpectrumPainter extends CustomPainter {
  final List<double> bars;
  SpectrumPainter({required this.bars});

  @override
  void paint(Canvas canvas, Size size) {
    final barW = size.width / bars.length;
    for (int i = 0; i < bars.length; i++) {
      final v = bars[i];
      final h = v * size.height;
      final hue = 180 + (i / bars.length) * 150;
      final paint = Paint()
        ..color = HSLColor.fromAHSL(v, hue, 1.0, 0.6).toColor();
      canvas.drawRect(
        Rect.fromLTWH(i * barW + 1, size.height - h, barW - 2, h),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(SpectrumPainter old) => true;
}
