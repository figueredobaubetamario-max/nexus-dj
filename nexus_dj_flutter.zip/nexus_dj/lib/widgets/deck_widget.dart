import 'dart:math';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import '../theme.dart';

class DeckWidget extends StatefulWidget {
  final String deckId;
  const DeckWidget({super.key, required this.deckId});
  @override
  State<DeckWidget> createState() => _DeckWidgetState();
}

class _DeckWidgetState extends State<DeckWidget> with SingleTickerProviderStateMixin {
  late AnimationController _vinylCtrl;
  double _vinylAngle = 0;

  @override
  void initState() {
    super.initState();
    _vinylCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..addListener(() {
        setState(() => _vinylAngle = _vinylCtrl.value * 2 * pi);
      });
  }

  @override
  void dispose() {
    _vinylCtrl.dispose();
    super.dispose();
  }

  DeckState get deck {
    final state = context.read<DJAppState>();
    return widget.deckId == 'A' ? state.deckA : state.deckB;
  }

  Color get accentColor => widget.deckId == 'A' ? kAccentA : kAccentB;

  Future<void> _loadFile() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.audio);
    if (result != null && result.files.single.path != null) {
      final d = context.read<DJAppState>();
      final dk = widget.deckId == 'A' ? d.deckA : d.deckB;
      await dk.loadFile(result.files.single.path!, result.files.single.name);
    }
  }

  void _updateVinyl(DeckState dk) {
    if (dk.isPlaying && !_vinylCtrl.isAnimating) {
      _vinylCtrl.repeat();
    } else if (!dk.isPlaying && _vinylCtrl.isAnimating) {
      _vinylCtrl.stop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<DJAppState>();
    final dk = widget.deckId == 'A' ? state.deckA : state.deckB;
    _updateVinyl(dk);

    return Container(
      color: kPanel,
      padding: const EdgeInsets.all(8),
      child: Column(
        children: [
          _buildWaveform(dk),
          const SizedBox(height: 6),
          _buildVinyl(dk),
          const SizedBox(height: 4),
          _buildTrackInfo(dk),
          const SizedBox(height: 4),
          _buildBeatIndicator(dk),
          const SizedBox(height: 4),
          _buildPitch(dk),
          const SizedBox(height: 4),
          _buildLoops(dk),
          const SizedBox(height: 4),
          _buildTransport(dk),
          const SizedBox(height: 4),
          _buildHotCues(dk),
          const SizedBox(height: 4),
          _buildLoadBtn(),
        ],
      ),
    );
  }

  Widget _buildWaveform(DeckState dk) {
    return GestureDetector(
      onTapDown: (d) => _scrubTo(dk, d.localPosition.dx),
      child: Container(
        height: 52,
        decoration: BoxDecoration(
          color: const Color(0xFF080810),
          borderRadius: BorderRadius.circular(4),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: CustomPaint(
            painter: WaveformPainter(
              data: dk.waveformData,
              progress: dk.duration.inMilliseconds > 0
                  ? dk.position.inMilliseconds / dk.duration.inMilliseconds
                  : 0.0,
              color: accentColor,
            ),
            child: const SizedBox.expand(),
          ),
        ),
      ),
    );
  }

  void _scrubTo(DeckState dk, double x) {
    final width = context.size?.width ?? 160;
    final pct = (x / width).clamp(0.0, 1.0);
    final ms = (pct * dk.duration.inMilliseconds).toInt();
    dk.player.seek(Duration(milliseconds: ms));
  }

  Widget _buildVinyl(DeckState dk) {
    return GestureDetector(
      onVerticalDragUpdate: (d) {
        if (dk.isPlaying) {
          final rate = (dk.player.speed - d.delta.dy * 0.05).clamp(-3.0, 3.0);
          dk.player.setSpeed(rate);
        }
      },
      onVerticalDragEnd: (_) {
        dk.player.setSpeed(dk.playbackRate.clamp(0.1, 3.0));
      },
      child: SizedBox(
        width: 80,
        height: 80,
        child: CustomPaint(
          painter: VinylPainter(angle: _vinylAngle, color: accentColor),
        ),
      ),
    );
  }

  Widget _buildTrackInfo(DeckState dk) {
    return Column(
      children: [
        Text(
          dk.trackName ?? '— NO TRACK LOADED —',
          style: const TextStyle(fontSize: 9, color: kText, letterSpacing: 0.5),
          overflow: TextOverflow.ellipsis,
          maxLines: 1,
        ),
        const SizedBox(height: 2),
        Text(
          '${_fmt(dk.position)} / ${_fmt(dk.duration)}  •  ${dk.bpm.toStringAsFixed(1)} BPM',
          style: const TextStyle(fontSize: 8, color: kTextDim),
        ),
      ],
    );
  }

  String _fmt(Duration d) {
    final m = d.inMinutes;
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  Widget _buildBeatIndicator(DeckState dk) {
    final bps = dk.bpm / 60;
    final beatFrac = (dk.position.inMilliseconds / 1000 * bps) % 1.0;
    final onBeat = beatFrac < 0.15;
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        AnimatedContainer(
          duration: const Duration(milliseconds: 50),
          width: 8,
          height: 8,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: onBeat ? kAccentG : kTextDim,
            boxShadow: onBeat ? [BoxShadow(color: kAccentG.withOpacity(0.7), blurRadius: 8)] : [],
          ),
        ),
        const SizedBox(width: 6),
        const Text('BEAT', style: TextStyle(fontSize: 8, color: kTextDim, letterSpacing: 3)),
      ],
    );
  }

  Widget _buildPitch(DeckState dk) {
    return Row(
      children: [
        const Text('PITCH', style: TextStyle(fontSize: 8, color: kTextDim, letterSpacing: 1)),
        const SizedBox(width: 4),
        Expanded(
          child: SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: accentColor,
              inactiveTrackColor: kBg3,
              thumbColor: accentColor,
            ),
            child: Slider(
              value: dk.pitch,
              min: -10,
              max: 10,
              onChanged: (v) => dk.setPitch(v),
            ),
          ),
        ),
        Text(
          '${dk.pitch >= 0 ? '+' : ''}${dk.pitch.toStringAsFixed(1)}%',
          style: TextStyle(fontSize: 8, color: accentColor),
        ),
      ],
    );
  }

  Widget _buildLoops(DeckState dk) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [0.5, 1.0, 2.0, 4.0, 8.0].map((bars) {
        final active = dk.loopActive && dk.loopBars == bars;
        return _miniBtn(
          bars == 0.5 ? '½' : bars.toInt().toString(),
          active: active,
          color: kAccentG,
          onTap: () => dk.setLoop(bars),
        );
      }).toList(),
    );
  }

  Widget _buildTransport(DeckState dk) {
    return Row(
      children: [
        _transpBtn('CUE', kText, onTap: () {
          if (dk.isPlaying) {
            dk.setCue();
          } else {
            dk.jumpToCue();
          }
        }),
        const SizedBox(width: 6),
        Expanded(
          child: GestureDetector(
            onTap: () => dk.togglePlay(),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: dk.isPlaying ? accentColor.withOpacity(0.1) : const Color(0xFF0D0D1A),
                border: Border.all(color: accentColor),
                borderRadius: BorderRadius.circular(4),
                boxShadow: dk.isPlaying
                    ? [BoxShadow(color: accentColor.withOpacity(0.3), blurRadius: 12)]
                    : [],
              ),
              child: Center(
                child: Text(
                  dk.isPlaying ? '⏸' : '▶',
                  style: TextStyle(fontSize: 18, color: accentColor),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(width: 6),
        _transpBtn(
          'SYNC',
          kAccentG,
          active: dk.syncEnabled,
          onTap: () {
            dk.syncEnabled = !dk.syncEnabled;
            if (dk.syncEnabled) {
              final master = context.read<DJAppState>().masterBpm;
              dk.syncTo(master);
            } else {
              dk.player.setSpeed(dk.playbackRate.clamp(0.1, 3.0));
            }
            dk.notifyListeners();
          },
        ),
      ],
    );
  }

  Widget _transpBtn(String label, Color color, {bool active = false, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        decoration: BoxDecoration(
          color: active ? color.withOpacity(0.15) : const Color(0xFF0D0D1A),
          border: Border.all(color: active ? color : kBorder),
          borderRadius: BorderRadius.circular(4),
          boxShadow: active ? [BoxShadow(color: color.withOpacity(0.3), blurRadius: 8)] : [],
        ),
        child: Text(label, style: TextStyle(fontSize: 9, color: active ? color : kText, letterSpacing: 1)),
      ),
    );
  }

  Widget _buildHotCues(DeckState dk) {
    return Row(
      children: List.generate(4, (i) {
        final set = dk.hotCues[i] != null;
        return Expanded(
          child: Padding(
            padding: EdgeInsets.only(left: i == 0 ? 0 : 4),
            child: GestureDetector(
              onTap: () => dk.triggerHotCue(i),
              onLongPress: () => dk.clearHotCue(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                padding: const EdgeInsets.symmetric(vertical: 7),
                decoration: BoxDecoration(
                  color: set ? kAccentC.withOpacity(0.15) : const Color(0xFF0D0D1A),
                  border: Border.all(color: set ? kAccentC : kBorder),
                  borderRadius: BorderRadius.circular(3),
                ),
                child: Center(
                  child: Text(
                    'C${i + 1}${set ? '✓' : ''}',
                    style: TextStyle(
                      fontSize: 9,
                      color: set ? kAccentC : kTextDim,
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      }),
    );
  }

  Widget _buildLoadBtn() {
    return GestureDetector(
      onTap: _loadFile,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFF0D0D1A),
          border: Border.all(color: kBorder, style: BorderStyle.solid),
          borderRadius: BorderRadius.circular(3),
        ),
        child: const Center(
          child: Text(
            '⬆  CARGAR PISTA',
            style: TextStyle(fontSize: 9, color: kTextDim, letterSpacing: 2),
          ),
        ),
      ),
    );
  }

  Widget _miniBtn(String label, {required bool active, required Color color, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        width: 32,
        height: 24,
        decoration: BoxDecoration(
          color: active ? color.withOpacity(0.15) : const Color(0xFF0D0D1A),
          border: Border.all(color: active ? color : kBorder),
          borderRadius: BorderRadius.circular(2),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(fontSize: 9, color: active ? color : kTextDim),
          ),
        ),
      ),
    );
  }
}

// ====== WAVEFORM PAINTER ======
class WaveformPainter extends CustomPainter {
  final List<double> data;
  final double progress;
  final Color color;
  WaveformPainter({required this.data, required this.progress, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    if (data.isEmpty) return;
    final barW = size.width / data.length;
    for (int i = 0; i < data.length; i++) {
      final v = data[i];
      final bh = v * size.height * 0.9;
      final played = i / data.length < progress;
      final paint = Paint()
        ..color = played ? color : color.withOpacity(0.25)
        ..style = PaintingStyle.fill;
      canvas.drawRect(
        Rect.fromLTWH(i * barW, (size.height - bh) / 2, max(1, barW - 1), bh),
        paint,
      );
    }
    // Playhead
    final x = progress * size.width;
    canvas.drawRect(
      Rect.fromLTWH(x - 1, 0, 2, size.height),
      Paint()..color = Colors.white,
    );
  }

  @override
  bool shouldRepaint(WaveformPainter old) =>
      old.progress != progress || old.data != data;
}

// ====== VINYL PAINTER ======
class VinylPainter extends CustomPainter {
  final double angle;
  final Color color;
  VinylPainter({required this.angle, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = size.width / 2;
    canvas.save();
    canvas.translate(c.dx, c.dy);
    canvas.rotate(angle);
    canvas.translate(-c.dx, -c.dy);

    // Vinyl body
    final bgPaint = Paint()..color = const Color(0xFF0D0D1A);
    canvas.drawCircle(c, r, bgPaint);

    // Grooves
    for (int i = 3; i < 9; i++) {
      canvas.drawCircle(
        c,
        r * i / 9,
        Paint()
          ..color = Colors.white.withOpacity(0.04)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1,
      );
    }

    // Outer ring glow
    canvas.drawCircle(
      c,
      r - 2,
      Paint()
        ..color = color
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2,
    );

    // Center label
    canvas.drawCircle(
      c,
      r * 0.28,
      Paint()..color = const Color(0xFF151525),
    );
    canvas.drawCircle(
      c,
      r * 0.28,
      Paint()
        ..color = color.withOpacity(0.4)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1,
    );

    // Center hole
    canvas.drawCircle(c, 4, Paint()..color = const Color(0xFF0A0A0F));

    canvas.restore();
  }

  @override
  bool shouldRepaint(VinylPainter old) => old.angle != angle;
}
