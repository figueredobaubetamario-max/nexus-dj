import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import '../theme.dart';

class MixerWidget extends StatelessWidget {
  const MixerWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<DJAppState>();
    return Container(
      color: kBg2,
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          const Text(
            'M I X E R  /  E Q',
            style: TextStyle(fontFamily: 'Orbitron', fontSize: 8, color: kTextDim, letterSpacing: 5),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _ChannelEQ(deck: state.deckA, color: kAccentA, label: 'A')),
              const SizedBox(width: 12),
              _VUMeter(state: state),
              const SizedBox(width: 12),
              Expanded(child: _ChannelEQ(deck: state.deckB, color: kAccentB, label: 'B')),
            ],
          ),
        ],
      ),
    );
  }
}

class _ChannelEQ extends StatelessWidget {
  final DeckState deck;
  final Color color;
  final String label;
  const _ChannelEQ({required this.deck, required this.color, required this.label});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _eqRow('HI', deck.eqHi, (v) {
          deck.eqHi = v;
          deck.notifyListeners();
        }, color),
        _eqRow('MID', deck.eqMid, (v) {
          deck.eqMid = v;
          deck.notifyListeners();
        }, color),
        _eqRow('LOW', deck.eqLow, (v) {
          deck.eqLow = v;
          deck.notifyListeners();
        }, color),
        const SizedBox(height: 6),
        _volRow(deck, color),
      ],
    );
  }

  Widget _eqRow(String lbl, double val, ValueChanged<double> onChange, Color color) {
    final db = ((val) * 12).toStringAsFixed(0);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          SizedBox(width: 24, child: Text(lbl, style: const TextStyle(fontSize: 8, color: kTextDim, letterSpacing: 1))),
          Expanded(
            child: SliderTheme(
              data: SliderTheme.of(_context!).copyWith(
                trackHeight: 3,
                activeTrackColor: color,
                inactiveTrackColor: kBg3,
                thumbColor: color,
                thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
                overlayShape: SliderComponentShape.noOverlay,
              ),
              child: Slider(
                value: val,
                min: -1,
                max: 1,
                onChanged: onChange,
              ),
            ),
          ),
          SizedBox(
            width: 28,
            child: Text(
              '${val >= 0 ? '+' : ''}$db',
              style: TextStyle(fontSize: 7, color: color),
              textAlign: TextAlign.right,
            ),
          ),
        ],
      ),
    );
  }

  Widget _volRow(DeckState deck, Color color) {
    return Row(
      children: [
        const SizedBox(width: 24, child: Text('VOL', style: TextStyle(fontSize: 8, color: kTextDim, letterSpacing: 1))),
        Expanded(
          child: SliderTheme(
            data: SliderTheme.of(_context!).copyWith(
              trackHeight: 5,
              activeTrackColor: color,
              inactiveTrackColor: kBg3,
              thumbColor: color,
              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 8),
            ),
            child: Slider(
              value: deck.volume,
              min: 0,
              max: 1.3,
              onChanged: (v) => deck.setVolume(v),
            ),
          ),
        ),
      ],
    );
  }

  // hack to access context in helper methods
  static BuildContext? _context;
}

// We need context for SliderTheme — use a Builder
class _VUMeter extends StatefulWidget {
  final DJAppState state;
  const _VUMeter({required this.state});
  @override
  State<_VUMeter> createState() => _VUMeterState();
}

class _VUMeterState extends State<_VUMeter> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  double _level = 0;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 80))
      ..addListener(() {
        setState(() => _level = (_level + (widget.state.deckA.isPlaying || widget.state.deckB.isPlaying ? 0.1 : -0.1)).clamp(0, 1));
      })
      ..repeat();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final segs = 12;
    final active = ((_level + (DateTime.now().millisecondsSinceEpoch % 300) / 300 * 0.3) * segs).toInt().clamp(0, segs);
    return Column(
      children: List.generate(segs, (i) {
        final idx = segs - 1 - i;
        Color c;
        if (idx >= segs * 0.85) c = kAccentB;
        else if (idx >= segs * 0.6) c = const Color(0xFFFFCC00);
        else c = kAccentG;
        return Container(
          width: 14,
          height: 4,
          margin: const EdgeInsets.only(bottom: 2),
          decoration: BoxDecoration(
            color: idx < active ? c : kBg3,
            borderRadius: BorderRadius.circular(1),
          ),
        );
      }),
    );
  }
}
